-- V BENE V3: ejecuta este SQL en Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'passenger' check (role in ('passenger','driver','admin')),
  full_name text not null default '',
  email text,
  phone text,
  national_id text unique,
  photo_url text,
  status text not null default 'active',
  created_at timestamptz not null default now()
);

create table if not exists public.driver_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  approval_status text not null default 'pending' check (approval_status in ('pending','approved','rejected','suspended')),
  vehicle_type text not null check (vehicle_type in ('car','motorcycle')),
  vehicle_brand_model text,
  plate text,
  documents_url text,
  approved_at timestamptz
);

create table if not exists public.trips (
  id uuid primary key default gen_random_uuid(),
  passenger_id uuid not null references public.profiles(id),
  driver_id uuid references public.profiles(id),
  origin_text text not null,
  destination_text text not null,
  origin_lat double precision,
  origin_lng double precision,
  destination_lat double precision,
  destination_lng double precision,
  vehicle_type text not null check (vehicle_type in ('car','motorcycle')),
  fare_bs numeric(14,2) not null default 0,
  status text not null default 'requested',
  payment_status text not null default 'pending_external',
  requested_at timestamptz not null default now(),
  accepted_at timestamptz,
  completed_at timestamptz
);

alter table public.profiles enable row level security;
alter table public.driver_profiles enable row level security;
alter table public.trips enable row level security;

create policy "users can read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
create policy "users can insert own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "users can update own profile" on public.profiles for update to authenticated using (auth.uid() = id);

create policy "drivers can read own driver profile" on public.driver_profiles for select to authenticated using (auth.uid() = user_id);
create policy "drivers can create own driver profile" on public.driver_profiles for insert to authenticated with check (auth.uid() = user_id);
create policy "drivers can update own driver profile" on public.driver_profiles for update to authenticated using (auth.uid() = user_id);

create policy "passengers can create own trips" on public.trips for insert to authenticated with check (auth.uid() = passenger_id);
create policy "passengers can read own trips" on public.trips for select to authenticated using (auth.uid() = passenger_id);
create policy "drivers can read assigned trips" on public.trips for select to authenticated using (auth.uid() = driver_id);
create policy "drivers can update assigned trips" on public.trips for update to authenticated using (auth.uid() = driver_id);

-- IMPORTANTE:
-- La cuenta admin no debe depender de una service_role key dentro de Flutter.
-- Las acciones administrativas deben ejecutarse mediante backend/Edge Functions
-- o políticas RLS específicas para una lista segura de administradores.
