# V Bene V3 — Supabase + autenticación + GPS

Esta versión incorpora:
- Supabase Auth para correo/contraseña.
- Perfil de usuario y rol.
- PostgreSQL con RLS.
- Solicitudes de viaje persistidas.
- GPS real con geolocator.
- Seguimiento de ubicación mientras la app está en uso.
- Permiso de ubicación Android.
- Pago externo: `payment_status = pending_external`.

## 1. Crear backend
Crea un proyecto en Supabase. En el SQL Editor ejecuta `supabase/schema.sql`.

## 2. Configurar la app
Obtén `Project URL` y `Publishable key` desde el panel Connect de Supabase.

Ejemplo:
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://TU-PROYECTO.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=TU_CLAVE_PUBLICABLE

Para compilar:
flutter build apk --release --dart-define=SUPABASE_URL=https://TU-PROYECTO.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=TU_CLAVE_PUBLICABLE

NO uses una service_role key dentro de la APK.

## 3. Qué queda pendiente
- Mapa visual real (Google Maps/Mapbox) y geocodificación.
- Matching en tiempo real entre pasajero y conductor.
- Notificaciones push.
- Subida segura de documentos/fotos.
- Panel web admin conectado.
- Reglas administrativas/RLS completas.
- Cálculo real de tarifas.
- Pruebas de seguridad y publicación.

La documentación actual de Supabase recomienda usar la publishable key en aplicaciones cliente y RLS para proteger tablas; las claves service_role deben permanecer en un servidor de confianza.
