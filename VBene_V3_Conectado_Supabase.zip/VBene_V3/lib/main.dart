import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isEmpty || supabasePublishableKey.isEmpty) {
    runApp(const ConfigMissingApp());
    return;
  }
  await Supabase.initialize(url: supabaseUrl, publishableKey: supabasePublishableKey);
  runApp(const VBeneApp());
}

final supabase = Supabase.instance.client;

class ConfigMissingApp extends StatelessWidget {
  const ConfigMissingApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    home: Scaffold(
      appBar: AppBar(title: const Text('V Bene')),
      body: const Padding(
        padding: EdgeInsets.all(24),
        child: Text('Falta configurar SUPABASE_URL y SUPABASE_PUBLISHABLE_KEY.\n\n'
          'Ejecuta la app pasando esas variables con --dart-define. Mira README.md.'),
      ),
    ),
  );
}

class VBeneApp extends StatelessWidget {
  const VBeneApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'V Bene',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F46)), useMaterial3: true),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: supabase.auth.onAuthStateChange,
    builder: (_, snap) {
      if (supabase.auth.currentSession == null) return const WelcomePage();
      return const PassengerHome();
    },
  );
}

class WelcomePage extends StatelessWidget {
  const WelcomePage({super.key});
  @override Widget build(BuildContext context) => Scaffold(
    body: Container(
      decoration: const BoxDecoration(gradient: LinearGradient(
        begin: Alignment.topCenter,end: Alignment.bottomCenter,
        colors: [Color(0xFF0B7F45),Color(0xFF064E2C)])),
      child: SafeArea(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          const Spacer(),
          const Text('🇻🇪', style: TextStyle(fontSize: 58)),
          const SizedBox(height: 14),
          const Text('Bienvenido a Uber V Bene', textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white,fontSize: 29,fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Viajes en moto y carro', style: TextStyle(color: Colors.white70)),
          const Spacer(),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const RegisterPage())),
            style: FilledButton.styleFrom(backgroundColor: Colors.white,foregroundColor: const Color(0xFF075A32),padding: const EdgeInsets.all(16)),
            child: const Text('Crear cuenta'))),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: OutlinedButton(
            onPressed: ()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const LoginPage())),
            style: OutlinedButton.styleFrom(foregroundColor: Colors.white,side: const BorderSide(color: Colors.white70),padding: const EdgeInsets.all(16)),
            child: const Text('Iniciar sesión'))),
          const SizedBox(height: 18),
        ]),
      )),
    ),
  );
}

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});
  @override State<RegisterPage> createState()=>_RegisterPageState();
}
class _RegisterPageState extends State<RegisterPage> {
  String role='passenger';
  final name=TextEditingController(), email=TextEditingController(), phone=TextEditingController(), cedula=TextEditingController(), password=TextEditingController();
  bool loading=false;
  @override void dispose(){for(final c in [name,email,phone,cedula,password]){c.dispose();}super.dispose();}
  Future<void> register() async {
    setState(()=>loading=true);
    try {
      final res=await supabase.auth.signUp(
        email: email.text.trim(), password: password.text,
        data: {'role':role,'full_name':name.text.trim(),'phone':phone.text.trim(),'national_id':cedula.text.trim()},
      );
      if(res.user!=null && mounted){
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Cuenta creada. Revisa tu correo si la confirmación está activada.')));
        Navigator.pop(context);
      }
    } on AuthException catch(e) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message)));
    } finally { if(mounted)setState(()=>loading=false); }
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Crear cuenta')),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      const Text('Datos personales',style:TextStyle(fontSize:25,fontWeight:FontWeight.bold)),
      const SizedBox(height:14),
      _field(name,'Nombre completo',Icons.person),
      _field(email,'Correo electrónico',Icons.email),
      _field(phone,'Teléfono',Icons.phone),
      _field(cedula,'Cédula de identidad',Icons.badge),
      TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Contraseña',prefixIcon:Icon(Icons.lock),border:OutlineInputBorder())),
      const SizedBox(height:16),
      SegmentedButton<String>(segments:const [
        ButtonSegment(value:'passenger',label:Text('Pasajero'),icon:Icon(Icons.person)),
        ButtonSegment(value:'driver',label:Text('Conductor'),icon:Icon(Icons.drive_eta)),
      ],selected:{role},onSelectionChanged:(s)=>setState(()=>role=s.first)),
      const SizedBox(height:20),
      FilledButton(onPressed:loading?null:register,child:Padding(padding:const EdgeInsets.all(14),child:Text(loading?'Creando...':'Crear cuenta'))),
    ]));
  Widget _field(TextEditingController c,String label,IconData icon)=>Padding(
    padding:const EdgeInsets.only(bottom:12),child:TextField(controller:c,decoration:InputDecoration(labelText:label,prefixIcon:Icon(icon),border:const OutlineInputBorder())));
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage>{
  final email=TextEditingController(),password=TextEditingController(); bool loading=false;
  Future<void> login()async{
    setState(()=>loading=true);
    try{await supabase.auth.signInWithPassword(email:email.text.trim(),password:password.text);}
    on AuthException catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.message)));}
    finally{if(mounted)setState(()=>loading=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Iniciar sesión')),
    body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
      TextField(controller:email,decoration:const InputDecoration(labelText:'Correo electrónico',border:OutlineInputBorder())),
      const SizedBox(height:12),TextField(controller:password,obscureText:true,decoration:const InputDecoration(labelText:'Contraseña',border:OutlineInputBorder())),
      const SizedBox(height:20),SizedBox(width:double.infinity,child:FilledButton(onPressed:loading?null:login,child:Text(loading?'Entrando...':'Entrar')))
    ]));
}

class PassengerHome extends StatefulWidget {
  const PassengerHome({super.key});
  @override State<PassengerHome> createState()=>_PassengerHomeState();
}
class _PassengerHomeState extends State<PassengerHome>{
  Position? position; StreamSubscription<Position>? sub; bool locating=false;
  Future<void> startGps()async{
    setState(()=>locating=true);
    try{
      if(!await Geolocator.isLocationServiceEnabled()) throw Exception('Activa el GPS del teléfono.');
      var p=await Geolocator.checkPermission();
      if(p==LocationPermission.denied)p=await Geolocator.requestPermission();
      if(p==LocationPermission.denied||p==LocationPermission.deniedForever)throw Exception('Permiso de ubicación no concedido.');
      position=await Geolocator.getCurrentPosition();
      await sub?.cancel();
      sub=Geolocator.getPositionStream(locationSettings:const LocationSettings(
        accuracy:LocationAccuracy.high,distanceFilter:10)).listen((p){if(mounted)setState(()=>position=p);});
    }catch(e){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));}
    finally{if(mounted)setState(()=>locating=false);}
  }
  @override void dispose(){sub?.cancel();super.dispose();}
  Future<void> logout()async=>supabase.auth.signOut();
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('V Bene'),actions:[IconButton(onPressed:logout,icon:const Icon(Icons.logout))]),
    body:Column(children:[
      Expanded(child:Container(margin:const EdgeInsets.all(16),decoration:BoxDecoration(color:const Color(0xFFE8F1EC),borderRadius:BorderRadius.circular(24)),
        child:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
          const Icon(Icons.location_on,size:70),const SizedBox(height:8),
          Text(position==null?'GPS sin activar':'GPS activo',style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
          const SizedBox(height:8),
          Text(position==null?'Pulsa el botón para obtener tu ubicación':
            'Lat: ${position!.latitude.toStringAsFixed(6)}\nLng: ${position!.longitude.toStringAsFixed(6)}',
            textAlign:TextAlign.center),
        ]))),
      Padding(padding:const EdgeInsets.fromLTRB(16,0,16,20),child:Column(children:[
        SizedBox(width:double.infinity,child:OutlinedButton.icon(
          onPressed:locating?null:startGps,icon:const Icon(Icons.my_location),label:Text(locating?'Obteniendo ubicación...':'Activar GPS'))),
        const SizedBox(height:8),
        SizedBox(width:double.infinity,child:FilledButton.icon(
          onPressed:()=>showModalBottomSheet(context:context,showDragHandle:true,builder:(_)=>const TripSheet()),
          icon:const Icon(Icons.search),label:const Padding(padding:EdgeInsets.all(14),child:Text('¿A dónde vamos?')))),
      ])),
    ]));
}

class TripSheet extends StatelessWidget {
  const TripSheet({super.key});
  Future<void> createTrip(BuildContext context)async{
    final uid=supabase.auth.currentUser?.id;
    if(uid==null)return;
    try{
      await supabase.from('trips').insert({
        'passenger_id':uid,'origin_text':'Ubicación actual','destination_text':'Destino seleccionado',
        'vehicle_type':'car','fare_bs':3000,'status':'requested','payment_status':'pending_external'
      });
      if(context.mounted)Navigator.pop(context);
    }catch(e){if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('No se pudo solicitar: $e')));}
  }
  @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisSize:MainAxisSize.min,children:[
    const Text('Solicitar corrida',style:TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    const TextField(decoration:InputDecoration(labelText:'Destino',prefixIcon:Icon(Icons.location_on),border:OutlineInputBorder())),
    const SizedBox(height:12),
    const Text('Ejemplo: Bs. 3.000 • pago directo al conductor'),
    const SizedBox(height:14),
    SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>createTrip(context),child:const Text('Solicitar corrida'))),
    const SizedBox(height:10),
  ]));
}
