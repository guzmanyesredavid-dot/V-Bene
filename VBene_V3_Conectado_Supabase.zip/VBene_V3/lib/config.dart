// V Bene - Supabase configuration
// This is the publishable client key; do NOT put a service_role/secret key here.
const supabaseUrl = 'https://rvfxhjafpmqjlvnoolwq.supabase.co';
const supabasePublishableKey = 'sb_publishable_ZE1EKb0Zr3BFkULgK_oJFg_MWeenUjg';
